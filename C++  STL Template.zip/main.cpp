//#include<stdio.h>
//#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main(){

	return 0;
}
